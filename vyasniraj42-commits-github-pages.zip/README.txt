Janki Selection - Static website ready for GitHub Pages
Files included:
- index.html
- style.css
- script.js
- images/  <-- add your product images here (p1.jpg ... p10.jpg)

Steps to publish as a USER SITE (recommended URL: https://vyasniraj42-commits.github.io ):
1. Create a new GitHub repository named: vyasniraj42-commits.github.io
2. Upload all files from this zip to the repository root (you can drag-and-drop using GitHub website).
3. Commit and push. GitHub Pages will publish automatically within a minute or two.
4. Add your product images into the 'images' folder (p1.jpg ... p10.jpg) via GitHub web or push via git.
Notes:
- If you name the repo exactly 'vyasniraj42-commits.github.io' the site will be available at https://vyasniraj42-commits.github.io
- Alternatively, you can create any repo and enable Pages from main branch, but URL will be different.
